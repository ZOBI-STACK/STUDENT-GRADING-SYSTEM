﻿Public Class Form1

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim marks As Integer
        marks = InputBox("Enter marks.", "Result", "0")
        If marks > 40 Then
            MsgBox("Congratulations! You Passed")
        Else
            MsgBox("Sorry! You Faild")
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim MARKS As Integer
        MARKS = InputBox("Enter Marks")
        If MARKS >= 80 Then
            MsgBox("A Grade")
        ElseIf MARKS >= 60 Then
            MsgBox("B Grade")
        ElseIf MARKS >= 40 Then
            MsgBox("c Grade")
        Else
            MsgBox("You are Fail.")
        End If
    End Sub

